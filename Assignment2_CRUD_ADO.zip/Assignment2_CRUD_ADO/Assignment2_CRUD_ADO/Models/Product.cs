﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Assignment2_CRUD_ADO.Models
{
    public class Product
    {

        public int Id { set; get; }
        [Required]
        public string ProductName { set; get; }
        [Required]
        public string ProductDescription { set; get; }
        [Required]
        public string Price { set; get; }
        
      }
    }

