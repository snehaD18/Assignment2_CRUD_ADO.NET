﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment2_CRUD_ADO.Connection
{
    public class ConnectionString
    {

        private static string pName = "Data Source=LAPTOP-E0SERM59;Initial Catalog=Product_details;Integrated Security=True";
        //"Data Source=LAPTOP-E0SERM59;Initial Catalog=STUDENT_DETAILS;Integrated Security=True"
        public static string PName
        {
            get => pName;
        }
    }
}
