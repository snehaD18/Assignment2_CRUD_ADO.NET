﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Assignment2_CRUD_ADO.Models;

namespace Assignment2_CRUD_ADO.Controllers
{
    public class ProductController : Controller
    {
        ProductDataAccessLayer productDataAccessLayer = null;

        public ProductController()
        {
            productDataAccessLayer = new ProductDataAccessLayer();
        }
        //get product
        public IActionResult Index()
        {
            IEnumerable<Product> products = productDataAccessLayer.GetAllProduct();
            return View(products);
            
        }
        // GET: product/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: product/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Product product)
        {
            try
            {
                // TODO: Add insert logic here  
                productDataAccessLayer.AddProduct(product);

                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: Student/Edit/5
        public ActionResult Edit(int id)
        {
            Product product = productDataAccessLayer.GetProductData(id);
            return View(product);

        }

        // POST: product/Edit/

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Product product)
        {
            try
            {
                // TODO: Add update logic here  
                productDataAccessLayer.UpdateProduct(product);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: product/Delete/
        public ActionResult Delete(int id)
        {
            Product product = productDataAccessLayer.GetProductData(id);
            return View(product);

        }

        // POST: product/Delete/
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(Product product)
        {
            try
            {
                // TODO: Add delete logic here  
                productDataAccessLayer.DeleteProduct(product.Id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }


    }
}